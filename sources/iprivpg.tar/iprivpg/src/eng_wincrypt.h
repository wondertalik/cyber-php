/*
   Copyright (C) 1998-2005 CyberPlat. All Rights Reserved.
   e-mail: support@cyberplat.com
*/

#ifndef __ENG_WINCRYPT_H
#define __ENG_WINCRYPT_H


#include "ipriv.h"

int eng_wincrypt_init(IPRIV_ENGINE* eng);
int eng_wincrypt_done(IPRIV_ENGINE* eng);


#endif
