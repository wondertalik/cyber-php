<?php

$sec = file_get_contents('../test/secret.key');
$pub = file_get_contents('../test/public.key');
$passwd = '1111111111';

$res = ipriv_sign("Hello world", $sec, $passwd);
print "Sign: $res[0]\n";
if (!$res[0])
    print("\n$res[1]\n");
print "\n";

$res = ipriv_verify($res[1], $pub);
print "Verify: $res[0]\n";
if (!$res[0])
    print("\n$res[1]\n");
print "\n";

?>
