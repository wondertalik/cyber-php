import org.CyberPlat.*;

class test
{
    public static void main(String args[])
    {
	IPrivKey sec=null;
	IPrivKey pub=null;
	try
	{
	    sec=IPriv.openSecretKey("test/secret.key","1111111111");
	    pub=IPriv.openPublicKey("test/pubkeys.key",17033);

	    String s1=sec.signText("Привет");
	    System.out.println("\""+s1+"\"");

	    String s2=pub.verifyText(s1);
	    System.out.println("\""+s2+"\"");
	    
	    String s3=pub.encryptText("Привет");
	    System.out.println("\""+s3+"\"");

	    String s4=sec.decryptText(s3);
	    System.out.println("\""+s4+"\"");

	    String s5=sec.signText2("Привет");
	    System.out.println("\""+s5+"\"");

	    String s6=pub.verifyText2("Привет",s5);
	    System.out.println("\""+s6+"\"");

	    
	}
	catch(Exception e)
	{
	    System.out.println(e.toString());	    
	}
	
	if(sec!=null)
	    IPriv.closeKey(sec);
	if(pub!=null)
	    IPriv.closeKey(pub);
    }
}
